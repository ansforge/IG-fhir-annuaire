# AS CodeableConceptTimed Datatype Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS CodeableConceptTimed Datatype Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-codeableconcept-timed-definitions.md) 
*  [Mappings](StructureDefinition-as-codeableconcept-timed-mappings.md) 
*  [XML](StructureDefinition-as-codeableconcept-timed.profile.xml.md) 
*  [JSON](StructureDefinition-as-codeableconcept-timed.profile.json.md) 
*  [TTL](StructureDefinition-as-codeableconcept-timed.profile.ttl.md) 

## Data Type Profile: AS CodeableConceptTimed Datatype Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-codeableconcept-timed | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsCodeableConceptTimedProfile |

 
Datatype profile créé à partir CodeableConcept dans le cadre de l’Annuaire Santé pour ajouter une extension Period au type CodeableConcept. 

**Usages:**

* Use this DataType Profile: [AS Practitioner Profile](StructureDefinition-as-practitioner.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-codeableconcept-timed)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [CodeableConcept](http://hl7.org/fhir/R4/datatypes.html#CodeableConcept) 

#### Constraints

#### Constraints

This structure is derived from [CodeableConcept](http://hl7.org/fhir/R4/datatypes.html#CodeableConcept) 

**Résumé**

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-codeableconcept-timed-metadata](StructureDefinition-as-ext-codeableconcept-timed-metadata.md)

 **Differential View** 

This structure is derived from [CodeableConcept](http://hl7.org/fhir/R4/datatypes.html#CodeableConcept) 

 **Key Elements View** 

#### Constraints

 **Snapshot View** 

#### Constraints

This structure is derived from [CodeableConcept](http://hl7.org/fhir/R4/datatypes.html#CodeableConcept) 

**Résumé**

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-codeableconcept-timed-metadata](StructureDefinition-as-ext-codeableconcept-timed-metadata.md)

 

Other representations of profile: [CSV](StructureDefinition-as-codeableconcept-timed.csv), [Excel](StructureDefinition-as-codeableconcept-timed.xlsx), [Schematron](StructureDefinition-as-codeableconcept-timed.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-address-extended.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-codeableconcept-timed-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

