# AS Organization Authorization Deadline Extension - Definitions - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Organization Authorization Deadline Extension**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-ext-organization-authorization-deadline.md) 
*  [Detailed Descriptions](#) 
*  [Mappings](StructureDefinition-as-ext-organization-authorization-deadline-mappings.md) 
*  [XML](StructureDefinition-as-ext-organization-authorization-deadline.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-organization-authorization-deadline.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-organization-authorization-deadline.profile.ttl.md) 

## Extension: AsOrganizationAuthorizationDeadlineExtension - Detailed Descriptions

| |
| :--- |
| Active as of 2025-10-08 |

Definitions for the as-ext-organization-authorization-deadline extension.

*  [Differential Elements Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Elements Table](#tabs-snap) 

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

Guidance on how to interpret the contents of this table can be found[here](https://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#data-dictionaries)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-organization-authorization-deadline.md) | [top](#top) |  [next>](StructureDefinition-as-ext-organization-authorization-deadline-mappings.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

