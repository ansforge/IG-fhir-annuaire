# AS CodeSystem OrganizationTypes - Testing - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS CodeSystem OrganizationTypes**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](CodeSystem-as-cs-organization-types.md) 
*  [XML](CodeSystem-as-cs-organization-types.xml.md) 
*  [JSON](CodeSystem-as-cs-organization-types.json.md) 
*  [TTL](CodeSystem-as-cs-organization-types.ttl.md) 

## CodeSystem: AS CodeSystem OrganizationTypes - Testing 

| |
| :--- |
| Active as of 2025-10-08 |

### Test Plans

**No test plans are currently available for the CodeSystem.**

### Test Scripts

**No test scripts are currently available for the CodeSystem.**

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-as-cs-organization-types.md) | [top](#top) |  [next>](CodeSystem-as-cs-organization-types.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

