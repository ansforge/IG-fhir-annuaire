# AS Donnée Publique HealthcareService Social Equipment Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Publique HealthcareService Social Equipment Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dp-healthcareservice-social-equipment-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-healthcareservice-social-equipment-mappings.md) 
*  [XML](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.xml.md) 
*  [JSON](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.ttl.md) 

## Resource Profile: AS Donnée Publique HealthcareService Social Equipment Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-healthcareservice-social-equipment | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDpHealthcareServiceSocialEquipmentProfile |

 
Profil public applicatif créé à partir du profil générique as-healthcareservice-social-equipment dans le contexte des données en accès libre de l’Annuaire Santé. Pour connaître les paramètres de recherches associés à ce profil, il suffit de consulter le CapabilityStatement AsServerCapabilityStatement. 

**Usages:**

* This Profile is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dp-healthcareservice-social-equipment)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsHealthcareServiceSocialEquipmentProfile](StructureDefinition-as-healthcareservice-social-equipment.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsHealthcareServiceSocialEquipmentProfile](StructureDefinition-as-healthcareservice-social-equipment.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 21 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of HealthcareService.meta.profile

 **Differential View** 

This structure is derived from [AsHealthcareServiceSocialEquipmentProfile](StructureDefinition-as-healthcareservice-social-equipment.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsHealthcareServiceSocialEquipmentProfile](StructureDefinition-as-healthcareservice-social-equipment.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 21 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of HealthcareService.meta.profile

 

Other representations of profile: [CSV](StructureDefinition-as-dp-healthcareservice-social-equipment.csv), [Excel](StructureDefinition-as-dp-healthcareservice-social-equipment.xlsx), [Schematron](StructureDefinition-as-dp-healthcareservice-social-equipment.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dp-healthcareservice-healthcare-activity.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dp-healthcareservice-social-equipment-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

