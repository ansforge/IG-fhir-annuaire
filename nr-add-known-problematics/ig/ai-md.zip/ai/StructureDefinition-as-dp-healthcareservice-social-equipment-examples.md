#  - Annuaire Santé v1.1.0

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-dp-healthcareservice-social-equipment.md) 
*  [Detailed Descriptions](StructureDefinition-as-dp-healthcareservice-social-equipment-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-healthcareservice-social-equipment-mappings.md) 
*  [XML](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.xml.md) 
*  [JSON](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.ttl.md) 

## Resource Profile: AsDpHealthcareServiceSocialEquipmentProfile - Examples

| |
| :--- |
| Active as of 2025-10-08 |

**No examples are currently available for the Profile.**

| | | |
| :--- | :--- | :--- |
|  <prev | [top](#top) |  next> |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

