# as-sp-insee-code - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **as-sp-insee-code**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](SearchParameter-as-sp-insee-code.xml.md) 
*  [JSON](SearchParameter-as-sp-insee-code.json.md) 
*  [TTL](SearchParameter-as-sp-insee-code.ttl.md) 

## SearchParameter: as-sp-insee-code 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/SearchParameter/as-sp-insee-code | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsInseeCode |

 
Paramètre de recherche pour récupérer une organisation, par code Insee. Cf http://www.sirius-upvm.net/doc/usuels/codes_postaux.html 

## AsInseeCode

Paramètre `address-insee`:`string`

Paramètre de recherche pour récupérer une organisation, par code Insee. Cf http://www.sirius-upvm.net/doc/usuels/codes_postaux.html

| | |
| :--- | :--- |
| Ressource | [Organization](http://hl7.org/fhir/R4/organization.html) |
| Expression | `address.extension.where(url='https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-address-insee-code').value` |
| Multiples | * multipleAnd: It's up to the server whether the parameter may repeat in order to specify multiple values that must all be true
* multipleOr: It's up to the server whether the parameter can have multiple values (separated by comma) where at least one must be true
 |

| | | |
| :--- | :--- | :--- |
|  [<prev](SearchParameter-as-sp-data-registration-authority.ttl.md) | [top](#top) |  [next>](SearchParameter-as-sp-insee-code-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

