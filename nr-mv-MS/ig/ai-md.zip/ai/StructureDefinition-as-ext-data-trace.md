# AS Data Trace Extension - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Data Trace Extension**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-ext-data-trace-definitions.md) 
*  [Mappings](StructureDefinition-as-ext-data-trace-mappings.md) 
*  [XML](StructureDefinition-as-ext-data-trace.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-data-trace.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-data-trace.profile.ttl.md) 

## Extension: AS Data Trace Extension 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDataTraceExtension |

Extension créée dans le cadre de l’Annuaire Santé pour tracer l’origine de la donnée (Autorité d’Enregistrement (AE) et Système d’Information (SI)). Des études complémentaires vont être initiées pour envisager l’usage de la ressource Provenance ou meta.source.

**Context of Use**

This extension may be used on the following element(s):

* Element ID Element

**Usage info**

**Usages:**

* Use this Extension: [AS Donnée Publique Device Profile](StructureDefinition-as-dp-device.md), [AS Donnée Publique HealthcareService Healthcare Activity Profile](StructureDefinition-as-dp-healthcareservice-healthcare-activity.md), [AS Donnée Publique HealthcareService Social Equipment Profile](StructureDefinition-as-dp-healthcareservice-social-equipment.md), [AS Donnée Publique Organization Profile](StructureDefinition-as-dp-organization.md)...Show 9 more,[AS Donnée Publique Practitioner Profile](StructureDefinition-as-dp-practitioner.md),[AS Donnée Publique PractitionerRole Profile](StructureDefinition-as-dp-practitionerrole.md),[AS Donnée Restreinte Device Profile](StructureDefinition-as-dr-device.md),[AS Donnée Restreinte HealthcareService Healthcare Activity Profile](StructureDefinition-as-dr-healthcareservice-healthcare-activity.md),[AS Donnée Restreinte HealthcareService Social Equipment Profile](StructureDefinition-as-dr-healthcareservice-social-equipment.md),[AS Donnée Restreinte Organization Profile](StructureDefinition-as-dr-organization.md),[AS Donnée Restreinte Person Profile](StructureDefinition-as-dr-person.md),[AS Donnée Restreinte Practitioner Profile](StructureDefinition-as-dr-practitioner.md)and[AS Donnée Restreinte PractitionerRole Profile](StructureDefinition-as-dr-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-ext-data-trace)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Extension complexe: Extension créée dans le cadre de l'Annuaire Santé pour tracer l'origine de la donnée (Autorité d'Enregistrement (AE) et Système d'Information (SI)). Des études complémentaires vont être initiées pour envisager l'usage de la ressource Provenance ou meta.source.

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Extension complexe: Extension créée dans le cadre de l'Annuaire Santé pour tracer l'origine de la donnée (Autorité d'Enregistrement (AE) et Système d'Information (SI)). Des études complémentaires vont être initiées pour envisager l'usage de la ressource Provenance ou meta.source.

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-as-ext-data-trace.csv), [Excel](StructureDefinition-as-ext-data-trace.xlsx), [Schematron](StructureDefinition-as-ext-data-trace.sch) 

#### Terminology Bindings

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-codeableconcept-timed-metadata.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-ext-data-trace-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

