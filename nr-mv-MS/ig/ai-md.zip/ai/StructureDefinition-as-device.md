# AS Device Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Device Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-device-definitions.md) 
*  [Mappings](StructureDefinition-as-device-mappings.md) 
*  [XML](StructureDefinition-as-device.profile.xml.md) 
*  [JSON](StructureDefinition-as-device.profile.json.md) 
*  [TTL](StructureDefinition-as-device.profile.ttl.md) 

## Resource Profile: AS Device Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-device | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDeviceProfile |

 
Profil générique créé à partir de Device dans le contexte de l’Annuaire Santé pour décrire les Equipements Matériels Lourds (EML) mis en place au sein d’un établissement. 

**Usages:**

* Derived from this Profile: [AS Donnée Publique Device Profile](StructureDefinition-as-dp-device.md) and [AS Donnée Restreinte Device Profile](StructureDefinition-as-dr-device.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-device)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [Device](http://hl7.org/fhir/R4/device.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [Device](http://hl7.org/fhir/R4/device.html) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

**Structures**

This structure refers to these other structures:

* [FR Core Organization Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html)
* [AS Organization Profile(https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-organization)](StructureDefinition-as-organization.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)
* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-authorization](StructureDefinition-as-ext-authorization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Device.identifier

 **Differential View** 

This structure is derived from [Device](http://hl7.org/fhir/R4/device.html) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [Device](http://hl7.org/fhir/R4/device.html) 

**Résumé**

Mandatory: 0 element(1 nested mandatory element)

**Structures**

This structure refers to these other structures:

* [FR Core Organization Profile(https://hl7.fr/ig/fhir/core/StructureDefinition/fr-core-organization)](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-organization.html)
* [AS Organization Profile(https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-organization)](StructureDefinition-as-organization.md)

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)
* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-authorization](StructureDefinition-as-ext-authorization.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Device.identifier

 

Other representations of profile: [CSV](StructureDefinition-as-device.csv), [Excel](StructureDefinition-as-device.xlsx), [Schematron](StructureDefinition-as-device.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](SearchParameter-as-sp-type-smartcard.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-device-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

