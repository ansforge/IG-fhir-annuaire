# example-organization-nancy - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **example-organization-nancy**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](Organization-example-organization-nancy.xml.md) 
*  [JSON](Organization-example-organization-nancy.json.md) 
*  [TTL](Organization-example-organization-nancy.ttl.md) 

## Example Organization: example-organization-nancy

Profil: [AS Organization Profile](StructureDefinition-as-organization.md)

**identifier**: Identification nationale de structure définie par l’ANS dans le CI_SIS/1540002698 (use: official, ), FINESS d'entité géographique/540002698

**active**: true

**name**: CHRU NANCY - HOPITAUX DE BRABOIS

**telecom**: ph: 0383153030, fax: 0383153522, [direction.generale@chu-nancy.fr](mailto:direction.generale@chu-nancy.fr), [exemple.address@address.mssante.fr](mailto:exemple.address@address.mssante.fr)

**address**: R DU MORVAN, 54511 VANDOEUVRE LES NANCY CEDEX VANDOEUVRE LES NANCY CEDEX 54511 

| | | |
| :--- | :--- | :--- |
|  [<prev](Organization-example-organization-fictive.ttl.md) | [top](#top) |  [next>](Organization-example-organization-nancy.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

