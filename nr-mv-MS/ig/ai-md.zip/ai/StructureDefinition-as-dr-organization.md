# AS Donnée Restreinte Organization Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Restreinte Organization Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dr-organization-definitions.md) 
*  [Mappings](StructureDefinition-as-dr-organization-mappings.md) 
*  [Examples](StructureDefinition-as-dr-organization-examples.md) 
*  [XML](StructureDefinition-as-dr-organization.profile.xml.md) 
*  [JSON](StructureDefinition-as-dr-organization.profile.json.md) 
*  [TTL](StructureDefinition-as-dr-organization.profile.ttl.md) 

## Resource Profile: AS Donnée Restreinte Organization Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dr-organization | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDrOrganizationProfile |

 
Profil restreint créé à partir de as-organization dans le contexte des données en accès restreint de l’Annuaire Santé. 

**Usages:**

* Examples for this Profile: [CH EURE-SEINE](Organization-158480.md), [PHARMACIE NOLOT](Organization-481677.md) and [CABINET SAINT ANTOINE](Organization-548812.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dr-organization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)
 Must-Support: 15 elements

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)

 **Differential View** 

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)
 Must-Support: 15 elements

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)

 

Other representations of profile: [CSV](StructureDefinition-as-dr-organization.csv), [Excel](StructureDefinition-as-dr-organization.xlsx), [Schematron](StructureDefinition-as-dr-organization.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dr-healthcareservice-social-equipment.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dr-organization-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

