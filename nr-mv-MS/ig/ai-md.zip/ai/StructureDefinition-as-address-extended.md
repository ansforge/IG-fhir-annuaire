# AS Address Extended Datatype Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Address Extended Datatype Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-address-extended-definitions.md) 
*  [Mappings](StructureDefinition-as-address-extended-mappings.md) 
*  [XML](StructureDefinition-as-address-extended.profile.xml.md) 
*  [JSON](StructureDefinition-as-address-extended.profile.json.md) 
*  [TTL](StructureDefinition-as-address-extended.profile.ttl.md) 

## Data Type Profile: AS Address Extended Datatype Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-address-extended | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsAddressExtendedProfile |

 
Datatype profile créé à partir de FrAddress dans le contexte de l’Annuaire Santé pour slicer Address.line. 

**Usages:**

* Use this DataType Profile: [AS Person Birth Place Extension](StructureDefinition-as-ext-person-birth-place.md), [AS Organization Profile](StructureDefinition-as-organization.md) and [AS Practitioner Profile](StructureDefinition-as-practitioner.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-address-extended)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [FRCoreAddressProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-address.html) 

#### Terminology Bindings (Differential)

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreAddressProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-address.html) 

**Résumé**

Must-Support: 2 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-careOf](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-careOf.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-additionalLocator.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-houseNumber.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-buildingNumberSuffix](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-buildingNumberSuffix.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameType](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetNameType.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-postBox.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameBase](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetNameBase.html)
* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-lieu-dit](StructureDefinition-as-ext-lieu-dit.md)

 **Differential View** 

This structure is derived from [FRCoreAddressProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-address.html) 

#### Terminology Bindings (Differential)

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [FRCoreAddressProfile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-address.html) 

**Résumé**

Must-Support: 2 elements

**Extensions**

This structure refers to these extensions:

* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-careOf](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-careOf.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-additionalLocator](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-additionalLocator.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-houseNumber.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-buildingNumberSuffix](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-buildingNumberSuffix.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameType](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetNameType.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-postBox.html)
* [http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetNameBase](http://hl7.org/fhir/extensions/5.2.0/StructureDefinition-iso21090-ADXP-streetNameBase.html)
* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-lieu-dit](StructureDefinition-as-ext-lieu-dit.md)

 

Other representations of profile: [CSV](StructureDefinition-as-address-extended.csv), [Excel](StructureDefinition-as-address-extended.xlsx), [Schematron](StructureDefinition-as-address-extended.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-practitionerrole.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-address-extended-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

