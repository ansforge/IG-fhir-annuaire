# AS Donnée Restreinte Practitioner Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Restreinte Practitioner Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dr-practitioner-definitions.md) 
*  [Mappings](StructureDefinition-as-dr-practitioner-mappings.md) 
*  [Examples](StructureDefinition-as-dr-practitioner-examples.md) 
*  [XML](StructureDefinition-as-dr-practitioner.profile.xml.md) 
*  [JSON](StructureDefinition-as-dr-practitioner.profile.json.md) 
*  [TTL](StructureDefinition-as-dr-practitioner.profile.ttl.md) 

## Resource Profile: AS Donnée Restreinte Practitioner Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dr-practitioner | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDrPractitionerProfile |

 
Profil restreint créé à partir de as-practitioner dans le contexte des données en accès restreint de l’Annuaire Santé. 

**Usages:**

* Examples for this Profile: [Practitioner/334081](Practitioner-334081.md) and [Practitioner/3719500](Practitioner-3719500.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dr-practitioner)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

**Résumé**

Mandatory: 2 elements(2 nested mandatory elements)
 Must-Support: 8 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)

 **Differential View** 

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

**Résumé**

Mandatory: 2 elements(2 nested mandatory elements)
 Must-Support: 8 elements
 Prohibited: 1 element

**Extensions**

This structure refers to these extensions:

* [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-data-trace](StructureDefinition-as-ext-data-trace.md)

 

Other representations of profile: [CSV](StructureDefinition-as-dr-practitioner.csv), [Excel](StructureDefinition-as-dr-practitioner.xlsx), [Schematron](StructureDefinition-as-dr-practitioner.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dr-person.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dr-practitioner-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

