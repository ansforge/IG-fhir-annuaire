# pp19dr-practitioner-role-sal - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp19dr-practitioner-role-sal**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](PractitionerRole-1578230.xml.md) 
*  [JSON](PractitionerRole-1578230.json.md) 
*  [TTL](PractitionerRole-1578230.ttl.md) 

## Example PractitionerRole: pp19dr-practitioner-role-sal

version: 0.1; Dernière mise à jour : 2019-09-05 01:00:00+0100; Langue : fr; 

Information Source: [https://annuaire.sante.fr](https://annuaire.sante.fr)

Profils: [FR Core Practitioner Role](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html), [AS Donnée Restreinte PractitionerRole Profile](StructureDefinition-as-dr-practitionerrole.md)

**identifier**: `https://annuaire.sante.fr`/F58000880311022013

**active**: true

**period**: 2019-06-30 --> (ongoing)

**practitioner**: [Practitioner Arthur Saucier](Practitioner-334081.md)

**organization**: [Organization CH EURE-SEINE](Organization-158480.md)

**code**: Activité de soin et de pharmacie, Salarié, Fonction non définie

| | | |
| :--- | :--- | :--- |
|  [<prev](PractitionerRole-1738459.ttl.md) | [top](#top) |  [next>](PractitionerRole-1578230.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

