# AS Donnée Publique HealthcareService Healthcare Activity Profile - XML Representation - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Publique HealthcareService Healthcare Activity Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-dp-healthcareservice-healthcare-activity.md) 
*  [Detailed Descriptions](StructureDefinition-as-dp-healthcareservice-healthcare-activity-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-healthcareservice-healthcare-activity-mappings.md) 
*  [XML](#) 
*  [JSON](StructureDefinition-as-dp-healthcareservice-healthcare-activity.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-healthcareservice-healthcare-activity.profile.ttl.md) 

## Resource Profile: AsDpHealthcareServiceHealthcareActivityProfile - XML Profile

| |
| :--- |
| Active as of 2025-10-08 |

XML representation of the as-dp-healthcareservice-healthcare-activity resource profile.

[Raw xml](StructureDefinition-as-dp-healthcareservice-healthcare-activity.xml) | [Download](StructureDefinition-as-dp-healthcareservice-healthcare-activity.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dp-healthcareservice-healthcare-activity-testing.md) | [top](#top) |  [next>](StructureDefinition-as-dp-healthcareservice-healthcare-activity.profile.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

