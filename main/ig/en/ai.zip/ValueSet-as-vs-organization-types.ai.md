# AS ValueSet OrganizationTypes - Annuaire Santé v1.2.0-snapshot-3

## ValueSet: AS ValueSet OrganizationTypes 

 
ValueSet définissant les types d'organisation 

 **References** 

* [AS Organization Types](StructureDefinition-as-ext-organization-types.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "as-vs-organization-types",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/annuaire/ValueSet/as-vs-organization-types",
  "version" : "1.2.0-snapshot-3",
  "name" : "AsVsOrganizationTypes",
  "title" : "AS ValueSet OrganizationTypes",
  "status" : "draft",
  "date" : "2026-09-22T15:44:42+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    },
    {
      "system" : "email",
      "value" : "monserviceclient.annuaire@esante.gouv.fr"
    }]
  }],
  "description" : "ValueSet définissant les types d'organisation",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://interop.esante.gouv.fr/ig/fhir/annuaire/CodeSystem/as-cs-organization-types",
      "version" : "1.2.0-snapshot-3"
    }]
  }
}

```
