# AS Donnée Publique Organization Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Publique Organization Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dp-organization-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-organization-mappings.md) 
*  [Examples](StructureDefinition-as-dp-organization-examples.md) 
*  [XML](StructureDefinition-as-dp-organization.profile.xml.md) 
*  [JSON](StructureDefinition-as-dp-organization.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-organization.profile.ttl.md) 

## Resource Profile: AS Donnée Publique Organization Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-organization | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDpOrganizationProfile |

 
Profil public applicatif créé à partir du profil générique as-organization dans le contexte des données en libre accès de l’Annuaire Santé. Pour connaître les paramètres de recherches associés à ce profil, il suffit de consulter le CapabilityStatement AsServerCapabilityStatement. 

**Usages:**

* Examples for this Profile: [CH EURE-SEINE](Organization-158480DP.md), [PHARMACIE NOLOT](Organization-481677DP.md) and [CABINET SAINT ANTOINE](Organization-548812DP.md)
* CapabilityStatements using this Profile: [CapabilityStatement[https://interop.esante.gouv.fr/ig/fhir/annuaire/CapabilityStatement/AsServerDPCapabilityStatement|1.1.0]](CapabilityStatement-AsServerDPCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dp-organization)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 21 elements

 **Differential View** 

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsOrganizationProfile](StructureDefinition-as-organization.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 21 elements

 

Other representations of profile: [CSV](StructureDefinition-as-dp-organization.csv), [Excel](StructureDefinition-as-dp-organization.xlsx), [Schematron](StructureDefinition-as-dp-organization.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dp-healthcareservice-social-equipment.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dp-organization-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

