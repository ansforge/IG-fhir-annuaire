# pp19dp-practitioner-role-lib - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp19dp-practitioner-role-lib**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](PractitionerRole-1738459DP.xml.md) 
*  [JSON](PractitionerRole-1738459DP.json.md) 
*  [TTL](PractitionerRole-1738459DP.ttl.md) 

## Example PractitionerRole: pp19dp-practitioner-role-lib

version: 0.1; Dernière mise à jour : 2019-09-05 01:00:00+0100; Langue : fr; 

Information Source: [https://annuaire.sante.fr](https://annuaire.sante.fr)

Profils: [FR Core Practitioner Role](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html), [AS Donnée Publique PractitionerRole Profile](StructureDefinition-as-dp-practitionerrole.md)

**identifier**: `https://annuaire.sante.fr`/1010399870

**active**: true

**practitioner**: [Practitioner Arthur Saucier](Practitioner-334081.md)

**organization**: [Organization CABINET SAINT ANTOINE](Organization-548812.md)

**code**: Activité de soin et de pharmacie, Libéral, indépendant, artisan, commerçant, Fonction non définie

| | | |
| :--- | :--- | :--- |
|  [<prev](Practitioner-334081DP.ttl.md) | [top](#top) |  [next>](PractitionerRole-1738459DP.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

