# pp16dr-practitioner - XML Representation - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp16dr-practitioner**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](Practitioner-3719500.md) 
*  [XML](#) 
*  [JSON](Practitioner-3719500.json.md) 
*  [TTL](Practitioner-3719500.ttl.md) 

## : pp16dr-practitioner - XML Representation

[Raw xml](Practitioner-3719500.xml) | [Download](Practitioner-3719500.xml)

| | | |
| :--- | :--- | :--- |
|  [<prev](Practitioner-3719500.md) | [top](#top) |  [next>](Practitioner-3719500.json.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

