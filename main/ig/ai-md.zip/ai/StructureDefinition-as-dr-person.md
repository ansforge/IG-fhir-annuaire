# AS Donnée Restreinte Person Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Restreinte Person Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dr-person-definitions.md) 
*  [Mappings](StructureDefinition-as-dr-person-mappings.md) 
*  [Examples](StructureDefinition-as-dr-person-examples.md) 
*  [XML](StructureDefinition-as-dr-person.profile.xml.md) 
*  [JSON](StructureDefinition-as-dr-person.profile.json.md) 
*  [TTL](StructureDefinition-as-dr-person.profile.ttl.md) 

## Resource Profile: AS Donnée Restreinte Person Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dr-person | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDrPersonProfile |

 
Profil restreint créé à partir de as-person dans le contexte des données en accès restreint de l’Annuaire Santé. 

**Usages:**

* Examples for this Profile: [Person/pp16dr-person](Person-pp16dr-person.md) and [Person/pp19dr-person](Person-pp19dr-person.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dr-person)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsPersonProfile](StructureDefinition-as-person.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPersonProfile](StructureDefinition-as-person.md) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)
 Prohibited: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Person.meta.profile

 **Differential View** 

This structure is derived from [AsPersonProfile](StructureDefinition-as-person.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPersonProfile](StructureDefinition-as-person.md) 

**Résumé**

Mandatory: 0 element(2 nested mandatory elements)
 Prohibited: 1 element

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of Person.meta.profile

 

Other representations of profile: [CSV](StructureDefinition-as-dr-person.csv), [Excel](StructureDefinition-as-dr-person.xlsx), [Schematron](StructureDefinition-as-dr-person.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dr-organization.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dr-person-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

