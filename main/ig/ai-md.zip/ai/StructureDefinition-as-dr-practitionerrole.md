# AS Donnée Restreinte PractitionerRole Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Restreinte PractitionerRole Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dr-practitionerrole-definitions.md) 
*  [Mappings](StructureDefinition-as-dr-practitionerrole-mappings.md) 
*  [Examples](StructureDefinition-as-dr-practitionerrole-examples.md) 
*  [XML](StructureDefinition-as-dr-practitionerrole.profile.xml.md) 
*  [JSON](StructureDefinition-as-dr-practitionerrole.profile.json.md) 
*  [TTL](StructureDefinition-as-dr-practitionerrole.profile.ttl.md) 

## Resource Profile: AS Donnée Restreinte PractitionerRole Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dr-practitionerrole | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDrPractitionerRoleProfile |

 
Profil restreint créé à partir de as-practitionerrole dans le contexte des données en accès restreint de l’Annuaire Santé. 

**Usages:**

* Examples for this Profile: [PractitionerRole/1578230](PractitionerRole-1578230.md), [PractitionerRole/1738459](PractitionerRole-1738459.md) and [PractitionerRole/5015602](PractitionerRole-5015602.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dr-practitionerrole)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsPractitionerRoleProfile](StructureDefinition-as-practitionerrole.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerRoleProfile](StructureDefinition-as-practitionerrole.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 6 elements

 **Differential View** 

This structure is derived from [AsPractitionerRoleProfile](StructureDefinition-as-practitionerrole.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerRoleProfile](StructureDefinition-as-practitionerrole.md) 

**Résumé**

Mandatory: 1 element(2 nested mandatory elements)
 Prohibited: 6 elements

 

Other representations of profile: [CSV](StructureDefinition-as-dr-practitionerrole.csv), [Excel](StructureDefinition-as-dr-practitionerrole.xlsx), [Schematron](StructureDefinition-as-dr-practitionerrole.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dr-practitioner.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dr-practitionerrole-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

