# AS Installation Extension - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Installation Extension**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-ext-installation-definitions.md) 
*  [Mappings](StructureDefinition-as-ext-installation-mappings.md) 
*  [XML](StructureDefinition-as-ext-installation.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-installation.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-installation.profile.ttl.md) 

## Extension: AS Installation Extension 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-installation | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsInstallationExtension |

Extension créée dans le cadre de l’Annuaire Santé pour décrire les dates d’installation des équipements (HealthcareService) sanitaires, sociaux, médico-sociaux et d’enseignements

**Context of Use**

This extension may be used on the following element(s):

* Element ID HealthcareService
* Element ID Device

**Usage info**

**Usages:**

* Use this Extension: [AS HealthcareService Social Equipment Profile](StructureDefinition-as-healthcareservice-social-equipment.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-ext-installation)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Extension complexe: Extension créée dans le cadre de l'Annuaire Santé pour décrire les dates d'installation des équipements (HealthcareService) sanitaires, sociaux, médico-sociaux et d'enseignements

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Extension complexe: Extension créée dans le cadre de l'Annuaire Santé pour décrire les dates d'installation des équipements (HealthcareService) sanitaires, sociaux, médico-sociaux et d'enseignements

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-as-ext-installation.csv), [Excel](StructureDefinition-as-ext-installation.xlsx), [Schematron](StructureDefinition-as-ext-installation.sch) 

#### Terminology Bindings

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-education-level.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-ext-installation-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

