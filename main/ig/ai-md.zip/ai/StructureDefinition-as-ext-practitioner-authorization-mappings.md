# AS Practitioner Authorization Extension - Mappings - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Practitioner Authorization Extension**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-ext-practitioner-authorization.md) 
*  [Detailed Descriptions](StructureDefinition-as-ext-practitioner-authorization-definitions.md) 
*  [Mappings](#) 
*  [XML](StructureDefinition-as-ext-practitioner-authorization.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-practitioner-authorization.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-practitioner-authorization.profile.ttl.md) 

## Extension: AsPractitionerAuthorizationExtension - Mappings

| |
| :--- |
| Active as of 2025-10-08 |

Mappings for the as-ext-practitioner-authorization extension.

#### Mappings to Structures in this Implementation Guide

No Mappings Found

#### Mappings to other Structures

No Mappings Found

#### Other Mappings

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-practitioner-authorization-definitions.md) | [top](#top) |  [next>](StructureDefinition-as-ext-practitioner-authorization-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

