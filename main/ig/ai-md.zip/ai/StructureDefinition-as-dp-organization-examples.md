# AS Donnée Publique Organization Profile - Examples - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Publique Organization Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-dp-organization.md) 
*  [Detailed Descriptions](StructureDefinition-as-dp-organization-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-organization-mappings.md) 
*  [Examples](#) 
*  [XML](StructureDefinition-as-dp-organization.profile.xml.md) 
*  [JSON](StructureDefinition-as-dp-organization.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-organization.profile.ttl.md) 

## Resource Profile: AsDpOrganizationProfile - Examples

| |
| :--- |
| Active as of 2025-10-08 |

Examples for the as-dp-organization Profile.

| |
| :--- |
| [pp19dp-organization-eg-cab](Organization-158480DP.md) |
| [pp16dp-organization](Organization-481677DP.md) |
| [pp19dp-organization-ej-cab](Organization-548812DP.md) |

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dp-organization-testing.md) | [top](#top) |  [next>](StructureDefinition-as-dp-organization.profile.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

