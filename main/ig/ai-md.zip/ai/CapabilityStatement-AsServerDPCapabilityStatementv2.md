# AsServerDPCapabilityStatementv2 - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AsServerDPCapabilityStatementv2**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](CapabilityStatement-AsServerDPCapabilityStatementv2.xml.md) 
*  [JSON](CapabilityStatement-AsServerDPCapabilityStatementv2.json.md) 
*  [TTL](CapabilityStatement-AsServerDPCapabilityStatementv2.ttl.md) 

## CapabilityStatement: AsServerDPCapabilityStatementv2 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/CapabilityStatement/AsServerDPCapabilityStatementv2 | *Version*:1.1.0 |
| Active as of 2025-08-11 | *Computable Name*: |

 
CapabilityStatement décrivant les attendus de l’API v2 de l’annuaire santé. 

 [Raw OpenAPI-Swagger Definition file](AsServerDPCapabilityStatementv2.openapi.json) | [Download](AsServerDPCapabilityStatementv2.openapi.json) 

## 

* Version du guide dimplémentation : {0} 
* Version de FHIR : 4.0.1 
* Supported Formats: `json`
* Publié sur : 2025-08-11 13:49:59+0000 
* Publié par : Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris 

> **Note aux implémenteurs : capacités FHIR**Any FHIR capability may be 'allowed' by the system unless explicitly marked as 'SHALL NOT'. A few items are marked as MAY in the Implementation Guide to highlight their potential relevance to the use case.

## FHIR RESTful Capabilities

### Mode: server

### Capabilities by Resource/Profile

#### Résumé

Le tableau récapitulatif liste les ressources faisant partie de cette configuration, et pour chaque ressource, il liste :

* The relevant profiles (if any)
* Les interactions supportées par chaque ressource (**R**ead, **S**earch, **U**pdate, and **C**reate, are always shown, while **VR**ead, **P**atch, **D**elete, **H**istory on **I**nstance, or **H**istory on **T**les types sont seulement présents si au moins une des ressources les prend en charge.
* Les paramètres de recherche (SearchParameters) requis, recommandés, optionnels (le cas échéant).
* The linked resources enabled for `_include`
* The other resources enabled for `_revinclude`
* The operations on the resource (if any)

| | | | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| [Organization](#Organization1-1) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-organization](StructureDefinition-as-dp-organization.md) | y | y |  |  | _id, _lastUpdated, active, address, address-city, address-line, address-postalcode, data-information-system, data-registration-authority, identifier, identifier-type, mailbox-mss, name, partof, pharmacy-licence, type | `*`,`Organization:partof` | `Device:organization`,`HealthcareService:organization`,`PractitionerRole:organization` |  |
| [Device](#Device1-2) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-device](StructureDefinition-as-dp-device.md) | y | y |  |  | _id, _lastUpdated, data-information-system, data-registration-authority, identifier, manufacturer, model, organization, status, type | `*`,`Device:organization` |  |  |
| [Practitioner](#Practitioner1-3) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-practitioner](StructureDefinition-as-dp-practitioner.md) | y | y |  |  | _id, _lastUpdated, active, data-information-system, data-registration-authority, family, given, identifier, identifier-type, mailbox-mss, name, number-smartcard, qualification-code, type-smartcard |  | `PractitionerRole:practitioner` |  |
| [PractitionerRole](#PractitionerRole1-4) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-practitionerrole](StructureDefinition-as-dp-practitionerrole.md) | y | y |  |  | _id, _lastUpdated, active, data-information-system, data-registration-authority, identifier, mailbox-mss, organization, practitioner, role | `*`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |  |
| [HealthcareService](#HealthcareService1-5) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-healthcareservice-healthcare-activity](StructureDefinition-as-dp-healthcareservice-healthcare-activity.md) | y | y |  |  | _id, _lastUpdated, _profile, active, characteristic, data-information-system, data-registration-authority, identifier, organization, service-category, service-type | `*`,`HealthcareService:organization` |  |  |

-------

#### Resource Conformance: supported Organization

Base System Profile

[AS Donnée Publique Organization Profile](StructureDefinition-as-dp-organization.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `search-type`, `read`.

Paramètres de recherche


 

#### Resource Conformance: supported Device

Base System Profile

[AS Donnée Publique Device Profile](StructureDefinition-as-dp-device.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `search-type`, `read`.

Paramètres de recherche


 

#### Resource Conformance: supported Practitioner

Base System Profile

[AS Donnée Publique Practitioner Profile](StructureDefinition-as-dp-practitioner.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `search-type`, `read`.

Paramètres de recherche


 

#### Resource Conformance: supported PractitionerRole

Base System Profile

[AS Donnée Publique PractitionerRole Profile](StructureDefinition-as-dp-practitionerrole.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `search-type`, `read`.

Paramètres de recherche


 

#### Resource Conformance: supported HealthcareService

Base System Profile

[AS Donnée Publique HealthcareService Healthcare Activity Profile](StructureDefinition-as-dp-healthcareservice-healthcare-activity.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `search-type`, `read`.

Paramètres de recherche


 

| | | |
| :--- | :--- | :--- |
|  [<prev](CapabilityStatement-AsServerDPCapabilityStatementv1.ttl.md) | [top](#top) |  [next>](CapabilityStatement-AsServerDPCapabilityStatementv2-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

