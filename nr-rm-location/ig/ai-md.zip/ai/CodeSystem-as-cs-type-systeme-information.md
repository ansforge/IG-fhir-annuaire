# AS CodeSystem type de système d'information - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS CodeSystem type de système d'information**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](CodeSystem-as-cs-type-systeme-information.xml.md) 
*  [JSON](CodeSystem-as-cs-type-systeme-information.json.md) 
*  [TTL](CodeSystem-as-cs-type-systeme-information.ttl.md) 

## CodeSystem: AS CodeSystem type de système d'information 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/CodeSystem/as-cs-type-systeme-information | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsCsTypeSystemeInformation |

 
CodeSystem définissant les types de systèmes d’information pouvant alimenter l’annuaire santé. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [AsVsTypeSystemeInformationVS](ValueSet-as-vs-type-systeme-information.md)

Profil: [Shareable CodeSystem](http://hl7.org/fhir/R4/shareablecodesystem.html)

This case-sensitive code system `https://interop.esante.gouv.fr/ig/fhir/annuaire/CodeSystem/as-cs-type-systeme-information` defines the following codes:

| | | |
| :--- | :--- | :--- |
|  [<prev](CodeSystem-as-cs-organization-types.ttl.md) | [top](#top) |  [next>](CodeSystem-as-cs-type-systeme-information-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

