# AS Donnée Publique Practitioner Profile - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Publique Practitioner Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-dp-practitioner-definitions.md) 
*  [Mappings](StructureDefinition-as-dp-practitioner-mappings.md) 
*  [Examples](StructureDefinition-as-dp-practitioner-examples.md) 
*  [XML](StructureDefinition-as-dp-practitioner.profile.xml.md) 
*  [JSON](StructureDefinition-as-dp-practitioner.profile.json.md) 
*  [TTL](StructureDefinition-as-dp-practitioner.profile.ttl.md) 

## Resource Profile: AS Donnée Publique Practitioner Profile 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-dp-practitioner | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsDpPractitionerProfile |

 
Profil public applicatif créé à partir du profil générique as-practitioner dans le contexte des données en libre accès de l’Annuaire Santé. Pour connaître les paramètres de recherches associés à ce profil, il suffit de consulter le CapabilityStatement AsServerCapabilityStatement. 

**Usages:**

* Examples for this Profile: [Practitioner/334081DP](Practitioner-334081DP.md) and [Practitioner/3719500DP](Practitioner-3719500DP.md)
* CapabilityStatements using this Profile: [CapabilityStatement[https://interop.esante.gouv.fr/ig/fhir/annuaire/CapabilityStatement/AsServerDPCapabilityStatement|1.1.0]](CapabilityStatement-AsServerDPCapabilityStatement.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-dp-practitioner)

### Formal Views of Profile Content

 [Description of Profiles, Differentials, Snapshots and how the different presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential Table](#tabs-diff) 
*  [Key Elements Table](#tabs-key) 
*  [Snapshot Table](#tabs-snap) 
*  [Statistics/References](#tabs-summ) 
*  [All](#tabs-all) 

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

#### Terminology Bindings

#### Constraints

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

**Résumé**

Mandatory: 3 elements(2 nested mandatory elements)
 Prohibited: 22 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Practitioner.telecom (Closed)

 **Differential View** 

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

 **Key Elements View** 

#### Terminology Bindings

#### Constraints

 **Snapshot View** 

#### Terminology Bindings

#### Constraints

This structure is derived from [AsPractitionerProfile](StructureDefinition-as-practitioner.md) 

**Résumé**

Mandatory: 3 elements(2 nested mandatory elements)
 Prohibited: 22 elements

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 2 is sliced based on the values of Practitioner.telecom (Closed)

 

Other representations of profile: [CSV](StructureDefinition-as-dp-practitioner.csv), [Excel](StructureDefinition-as-dp-practitioner.xlsx), [Schematron](StructureDefinition-as-dp-practitioner.sch) 

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dp-organization.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-dp-practitioner-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

