# pp19dr-practitioner - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp19dr-practitioner**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](Practitioner-334081.xml.md) 
*  [JSON](Practitioner-334081.json.md) 
*  [TTL](Practitioner-334081.ttl.md) 

## Example Practitioner: pp19dr-practitioner

version: 0.1; Dernière mise à jour : 2019-09-05 01:00:00+0100; Langue : fr; 

Information Source: [https://annuaire.sante.fr](https://annuaire.sante.fr)

Profils: [FR Core Practitioner Profile](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner.html), [AS Donnée Restreinte Practitioner Profile](StructureDefinition-as-dr-practitioner.md)

> **AS Registration Extension**
* isFirst: true
* registeringOrganization: Ordre des médecins
* period: 2019-03-10 --> (ongoing)

> **AS Registration Extension**
* isFirst: false
* status: Définitif
* period: 2019-03-30 --> (ongoing)

**identifier**: Identifiant National de Professionnel de Santé/810003461033 (use: official, ), N° RPPS/10003461033 (use: official, )

**active**: true

**name**: Arthur Saucier 

**telecom**: ph: 0603590791, [jeromebonnet@hotmail.fr](mailto:jeromebonnet@hotmail.fr)

**address**: null 92140 CLAMART 92140 99100 

**gender**: Male

**birthDate**: 1995-01-08

> **qualification****code**:DE Docteur en médecine**period**: 2019-03-10 --> (ongoing)

> **qualification****code**:Médecin

**communication**: français

| | | |
| :--- | :--- | :--- |
|  [<prev](Person-pp19dr-person.ttl.md) | [top](#top) |  [next>](Practitioner-334081.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

