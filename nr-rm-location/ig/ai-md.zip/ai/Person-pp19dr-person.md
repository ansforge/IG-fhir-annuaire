# pp19dr-person - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp19dr-person**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](Person-pp19dr-person.xml.md) 
*  [JSON](Person-pp19dr-person.json.md) 
*  [TTL](Person-pp19dr-person.ttl.md) 

## Example Person: pp19dr-person

Profil: [AS Donnée Restreinte Person Profile](StructureDefinition-as-dr-person.md)

**AS Person Birth Place Extension**: NANTES

**name**: Artus Saucier (Official)

### Links

| | |
| :--- | :--- |
| - | **Target** |
| * | [Practitioner Arthur Saucier](Practitioner-334081DP.md) |

| | | |
| :--- | :--- | :--- |
|  [<prev](Organization-548812.ttl.md) | [top](#top) |  [next>](Person-pp19dr-person.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

