# AS Lieu Dit Extension - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Lieu Dit Extension**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-ext-lieu-dit-definitions.md) 
*  [Mappings](StructureDefinition-as-ext-lieu-dit-mappings.md) 
*  [XML](StructureDefinition-as-ext-lieu-dit.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-lieu-dit.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-lieu-dit.profile.ttl.md) 

## Extension: AS Lieu Dit Extension 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-lieu-dit | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsLieuDit |

Extension créée dans le cadre de l’Annuaire Santé pour indiquer le lieu dit

**Context of Use**

This extension may be used on the following element(s):

* Element ID Address.line

**Usage info**

**Usages:**

* Use this Extension: [AS Address Extended Datatype Profile](StructureDefinition-as-address-extended.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-ext-lieu-dit)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type string: Extension créée dans le cadre de l'Annuaire Santé pour indiquer le lieu dit

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type string: Extension créée dans le cadre de l'Annuaire Santé pour indiquer le lieu dit

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-as-ext-lieu-dit.csv), [Excel](StructureDefinition-as-ext-lieu-dit.xlsx), [Schematron](StructureDefinition-as-ext-lieu-dit.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-installation.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-ext-lieu-dit-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

