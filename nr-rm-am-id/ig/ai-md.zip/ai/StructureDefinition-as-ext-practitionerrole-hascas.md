# AS PractitionerRole Has CAS - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS PractitionerRole Has CAS**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](#) 
*  [Detailed Descriptions](StructureDefinition-as-ext-practitionerrole-hascas-definitions.md) 
*  [Mappings](StructureDefinition-as-ext-practitionerrole-hascas-mappings.md) 
*  [XML](StructureDefinition-as-ext-practitionerrole-hascas.profile.xml.md) 
*  [JSON](StructureDefinition-as-ext-practitionerrole-hascas.profile.json.md) 
*  [TTL](StructureDefinition-as-ext-practitionerrole-hascas.profile.ttl.md) 

## Extension: AS PractitionerRole Has CAS 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-ext-practitionerrole-hascas | *Version*:1.1.0 |
| Active as of 2025-10-08 | *Computable Name*:AsPractitionerRoleHasCas |

Extension créée dans le cadre de l’Annuaire Santé pour décrire le contrat d’accès aux soins (CAS), remplacée récemment par l’option pratique tarifaire maîtrisée (OPTAM).

**Context of Use**

This extension may be used on the following element(s):

* Element ID PractitionerRole

**Usage info**

**Usages:**

* Use this Extension: [AS PractitionerRole Profile](StructureDefinition-as-practitionerrole.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fhir.fr.annuaire|current/StructureDefinition/as-ext-practitionerrole-hascas)

### Formal Views of Extension Content

 [Description of Profiles, Differentials, Snapshots, and how the XML and JSON presentations work](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Text Summary](#tabs-summ) 
*  [Differential Table](#tabs-diff) 
*  [Snapshot Table](#tabs-snap) 
*  [All](#tabs-all) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type boolean: Extension créée dans le cadre de l'Annuaire Santé pour décrire le contrat d'accès aux soins (CAS), remplacée récemment par l'option pratique tarifaire maîtrisée (OPTAM).

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

**Résumé**

Simple Extension with the type boolean: Extension créée dans le cadre de l'Annuaire Santé pour décrire le contrat d'accès aux soins (CAS), remplacée récemment par l'option pratique tarifaire maîtrisée (OPTAM).

 **Differential View** 

This structure is derived from [Extension](http://hl7.org/fhir/R4/extensibility.html#Extension) 

 **Snapshot View** 

 

Other representations of profile: [CSV](StructureDefinition-as-ext-practitionerrole-hascas.csv), [Excel](StructureDefinition-as-ext-practitionerrole-hascas.xlsx), [Schematron](StructureDefinition-as-ext-practitionerrole-hascas.sch) 

#### Constraints

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-ext-practitionerrole-contracted.profile.ttl.md) | [top](#top) |  [next>](StructureDefinition-as-ext-practitionerrole-hascas-definitions.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

