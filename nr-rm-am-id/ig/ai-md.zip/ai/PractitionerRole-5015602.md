# pp16dr-practitioner-role - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **pp16dr-practitioner-role**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](PractitionerRole-5015602.xml.md) 
*  [JSON](PractitionerRole-5015602.json.md) 
*  [TTL](PractitionerRole-5015602.ttl.md) 

## Example PractitionerRole: pp16dr-practitioner-role

version: 0.1; Dernière mise à jour : 2019-08-31 01:00:00+0100; Langue : fr; 

Information Source: [https://annuaire.sante.fr](https://annuaire.sante.fr)

Profils: [FR Core Practitioner Role](https://hl7.fr/ig/fhir/core/2.1.0/StructureDefinition-fr-core-practitioner-role.html), [AS Donnée Restreinte PractitionerRole Profile](StructureDefinition-as-dr-practitionerrole.md)

**identifier**: `https://annuaire.sante.fr`/1001500032

**active**: true

**period**: 2019-01-31 --> (ongoing)

**practitioner**: [Practitioner David CHATELIER](Practitioner-3719500.md)

**organization**: [Organization PHARMACIE NOLOT](Organization-481677.md)

**code**: Activité de soin et de pharmacie, Libéral, indépendant, artisan, commerçant, Fonction non définie

| | | |
| :--- | :--- | :--- |
|  [<prev](Practitioner-3719500.ttl.md) | [top](#top) |  [next>](PractitionerRole-5015602.xml.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

