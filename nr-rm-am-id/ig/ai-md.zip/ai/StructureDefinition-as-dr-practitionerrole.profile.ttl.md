# AS Donnée Restreinte PractitionerRole Profile - TTL Representation - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AS Donnée Restreinte PractitionerRole Profile**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Content](StructureDefinition-as-dr-practitionerrole.md) 
*  [Detailed Descriptions](StructureDefinition-as-dr-practitionerrole-definitions.md) 
*  [Mappings](StructureDefinition-as-dr-practitionerrole-mappings.md) 
*  [Examples](StructureDefinition-as-dr-practitionerrole-examples.md) 
*  [XML](StructureDefinition-as-dr-practitionerrole.profile.xml.md) 
*  [JSON](StructureDefinition-as-dr-practitionerrole.profile.json.md) 
*  [TTL](#) 

## Resource Profile: AsDrPractitionerRoleProfile - TTL Profile

| |
| :--- |
| Active as of 2025-10-08 |

TTL representation of the as-dr-practitionerrole resource profile.

[Raw ttl](StructureDefinition-as-dr-practitionerrole.ttl) | [Download](StructureDefinition-as-dr-practitionerrole.ttl)

| | | |
| :--- | :--- | :--- |
|  [<prev](StructureDefinition-as-dr-practitionerrole.profile.json.md) | [top](#top) |  [next>](StructureDefinition-as-healthcareservice-healthcare-activity.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

