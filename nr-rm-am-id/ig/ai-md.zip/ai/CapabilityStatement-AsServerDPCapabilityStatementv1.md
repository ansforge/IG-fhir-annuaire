# AsServerDPCapabilityStatementv1 - Annuaire Santé v1.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AsServerDPCapabilityStatementv1**

Annuaire Santé - Local Development build (v1.1.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html)

*  [Narrative Content](#) 
*  [XML](CapabilityStatement-AsServerDPCapabilityStatementv1.xml.md) 
*  [JSON](CapabilityStatement-AsServerDPCapabilityStatementv1.json.md) 
*  [TTL](CapabilityStatement-AsServerDPCapabilityStatementv1.ttl.md) 

## CapabilityStatement: AsServerDPCapabilityStatementv1 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/annuaire/CapabilityStatement/AsServerDPCapabilityStatementv1 | *Version*:1.1.0 |
| Active as of 2024-03-23 | *Computable Name*:AsDPRestServerv1 |

 [Raw OpenAPI-Swagger Definition file](AsServerDPCapabilityStatementv1.openapi.json) | [Download](AsServerDPCapabilityStatementv1.openapi.json) 

## 

* Version du guide dimplémentation : {0} 
* Version de FHIR : 4.0.1 
* Supported Formats: `application/fhir+xml`, `xml`, `application/fhir+json`, `json`
* Publié sur : 2024-03-23 13:49:59+0000 
* Publié par : Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris 

> **Note aux implémenteurs : capacités FHIR**Any FHIR capability may be 'allowed' by the system unless explicitly marked as 'SHALL NOT'. A few items are marked as MAY in the Implementation Guide to highlight their potential relevance to the use case.

## FHIR RESTful Capabilities

### Mode: server

### Capabilities by Resource/Profile

#### Résumé

Le tableau récapitulatif liste les ressources faisant partie de cette configuration, et pour chaque ressource, il liste :

* The relevant profiles (if any)
* Les interactions supportées par chaque ressource (**R**ead, **S**earch, **U**pdate, and **C**reate, are always shown, while **VR**ead, **P**atch, **D**elete, **H**istory on **I**nstance, or **H**istory on **T**les types sont seulement présents si au moins une des ressources les prend en charge.
* Les paramètres de recherche (SearchParameters) requis, recommandés, optionnels (le cas échéant).
* The linked resources enabled for `_include`
* The other resources enabled for `_revinclude`
* The operations on the resource (if any)

| | | | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| [Device](#Device1-1) | [https://interop.esante.gouv.fr/ig/fhir/annuaire/StructureDefinition/as-device](StructureDefinition-as-device.md) | y | y | y | y | _id, _lastUpdated, _since, _total, data-information-system, data-registration-authority, device-name, identifier, location, manufacturer, model, organization, status, type | `*`,`Device:organization` | `Device:location`,`Device:organization`,`HealthcareService:organization`,`Organization:endpoint`,`Organization:partof`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |
| [HealthcareService](#HealthcareService1-2) | [http://hl7.org/fhir/StructureDefinition/HealthcareService](http://hl7.org/fhir/R4/healthcareservice.html) | y | y | y | y | _id, _lastUpdated, _profile, _since, _total, data-information-system, data-registration-authority, active, characteristic, identifier, organization, service-category, service-type | `*`,`HealthcareService:organization` | `Device:location`,`Device:organization`,`HealthcareService:organization`,`Organization:endpoint`,`Organization:partof`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |
| [Organization](#Organization1-3) | http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-organization | y | y | y | y | _id, _lastUpdated, _since, _total, data-information-system, data-registration-authority, address-insee, mailbox-mss, pharmacy-licence, active, address, address-city, address-country, address-postalcode, address-state, address-use, endpoint, identifier, name, partof, type | `*`,`Organization:partof` | `Device:location`,`Device:organization`,`HealthcareService:organization`,`Organization:endpoint`,`Organization:partof`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |
| [Practitioner](#Practitioner1-4) | http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-practitioner | y | y | y | y | _id, _lastUpdated, _since, _total, data-information-system, data-registration-authority, mailbox-mss, active, identifier, name | `*` | `Device:location`,`Device:organization`,`HealthcareService:organization`,`Organization:endpoint`,`Organization:partof`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |
| [PractitionerRole](#PractitionerRole1-5) | http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-practitionerrole | y | y | y | y | _id, _lastUpdated, _since, _total, data-information-system, data-registration-authority, mailbox-mss, number-smartcard, type-smartcard, active, family, given, identifier, name, organization, practitioner, role, specialty | `*`,`PractitionerRole:organization`,`PractitionerRole:partof`,`PractitionerRole:practitioner` | `Device:location`,`Device:organization`,`HealthcareService:organization`,`Organization:endpoint`,`Organization:partof`,`PractitionerRole:organization`,`PractitionerRole:practitioner` |  |

-------

#### Resource Conformance: supported Device

Base System Profile

[AS Device Profile](StructureDefinition-as-device.md)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `update`, `search-type`, `read`, `create`.

Paramètres de recherche


 

#### Resource Conformance: supported HealthcareService

Base System Profile

[HealthcareService](http://hl7.org/fhir/R4/healthcareservice.html)

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `update`, `search-type`, `read`, `create`.

Paramètres de recherche


 

#### Resource Conformance: supported Organization

Base System Profile

`http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-organization`

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `update`, `search-type`, `read`, `create`.

Paramètres de recherche


 

#### Resource Conformance: supported Practitioner

Base System Profile

`http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-practitioner`

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `update`, `search-type`, `read`, `create`.

Paramètres de recherche


 

#### Resource Conformance: supported PractitionerRole

Base System Profile

`http://interop.esante.gouv.fr/ig/fhir/annuaire-donnee-publique/StructureDefinition/as-practitionerrole`

Conformité au Profil

**SHALL**

Reference Policy

Résumé des interactions

* Supports `update`, `search-type`, `read`, `create`.

Paramètres de recherche


 

| | | |
| :--- | :--- | :--- |
|  [<prev](artifacts.md) | [top](#top) |  [next>](CapabilityStatement-AsServerDPCapabilityStatementv1-testing.md) |

 IG © 2020+ [Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris](https://esante.gouv.fr). Package ans.fhir.fr.annuaire#1.1.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-08 
  Liens: [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/annuaire/history.html) | [Issue sur l'IG](https://github.com/ansforge/IG-fhir-annuaire/issues) | [Issue sur l'API](https://github.com/ansforge/annuaire-sante-fhir-serveur/issues)  

